
// Placeholder for IPFS upload script using Pinata or Web3.Storage
// Example with Web3.Storage

const { Web3Storage, File } = require('web3.storage');
const fs = require('fs');
const path = require('path');

function makeStorageClient() {
  return new Web3Storage({ token: 'YOUR_API_TOKEN' });
}

async function uploadMetadata(filePath) {
  const content = fs.readFileSync(filePath);
  const files = [new File([content], path.basename(filePath))];
  const client = makeStorageClient();
  const cid = await client.put(files);
  console.log('Stored files with CID:', cid);
  return cid;
}

uploadMetadata('./metadata/sample.json');
