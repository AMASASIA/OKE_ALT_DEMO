
# OKE NFT/SBT System Setup Guide

## 🌐 Deploying to Vercel

1. Push the repo to GitHub
2. Connect your repo at https://vercel.com/import
3. Set the build directory to `/frontend`
4. Environment variables (if needed): `NEXT_PUBLIC_API_KEY`, etc.

## 📦 IPFS Metadata Upload

Use the `ipfs/uploadToIPFS.js` script:

```bash
npm install web3.storage
node ipfs/uploadToIPFS.js
```

Replace `YOUR_API_TOKEN` with your Web3.Storage token.

## 📋 Google Sheets Integration

Use the GAS script in `google_sheets/` to sync data into the app.
Trigger setup:
- `onEdit(e)` or Time-driven trigger

## ✉️ Gmail Notification

Set up Gmail API credentials and paste them in `gmail_api/credentials.json`.
Run the script for sending mint confirmations with QR code and signature.

## ✅ Local Dev

```bash
cd frontend
npm install
npm run dev
```

Access at `http://localhost:3000`

--- 
For support: avantamas@gmail.com
