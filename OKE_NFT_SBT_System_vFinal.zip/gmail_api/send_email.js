// Node.js script to send email via Gmail API
