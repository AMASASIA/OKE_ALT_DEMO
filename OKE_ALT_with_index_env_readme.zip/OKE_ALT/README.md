# OKE_ALT ローカル開発手順（日本語）

## 必要なツール
- Node.js（推奨: v18 以上）
- npm または yarn

## セットアップ手順

1. この ZIP を解凍する
2. ターミナルでこのプロジェクトのルートディレクトリに移動する

```bash
cd OKE_ALT
```

3. パッケージをインストールする

```bash
npm install
```

4. 開発サーバーを起動する

```bash
npm run dev
```

5. ブラウザで以下を開く：

```
http://localhost:3000
```

## .env.local の編集

必要に応じて .env.local の設定を変更してください。

---

以上です！
