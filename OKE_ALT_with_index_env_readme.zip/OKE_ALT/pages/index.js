export default function Home() {
  return (
    <div>
      <h1>OKE ALT App is Running</h1>
      <p>Welcome to your deployed Next.js app!</p>
    </div>
  );
}
