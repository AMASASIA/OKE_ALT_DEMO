
// Contract addresses from your deployment - UPDATE THESE
export const MUMBAI_OKE_NFT_ADDRESS = "YOUR_MUMBAI_OKE_NFT_ADDRESS";
export const MUMBAI_CCIP_SOURCE_ADDRESS = "YOUR_MUMBAI_CCIP_SOURCE_ADDRESS";

export const SEPOLIA_OKE_NFT_ADDRESS = "YOUR_SEPOLIA_OKE_NFT_ADDRESS";
export const SEPOLIA_CCIP_DESTINATION_ADDRESS = "YOUR_SEPOLIA_CCIP_DESTINATION_ADDRESS";

// Chain IDs
export const MUMBAI_CHAIN_ID = 80001;
export const SEPOLIA_CHAIN_ID = 11155111;

// Chainlink CCIP Chain Selectors
export const SEPOLIA_CHAIN_SELECTOR = "16015286601757825753";
export const MUMBAI_CHAIN_SELECTOR = "12532609583862916517";

export const rpcUrls = {
    [MUMBAI_CHAIN_ID]: process.env.MUMBAI_RPC_URL || "https://rpc-mumbai.maticvigil.com",
    [SEPOLIA_CHAIN_ID]: process.env.SEPOLIA_RPC_URL || "https://rpc.sepolia.org",
}
