
import { ethers, BrowserProvider, JsonRpcProvider, Signer } from "ethers";
import { MUMBAI_CHAIN_ID, rpcUrls } from "./constants";

declare global {
    interface Window {
        ethereum?: any;
    }
}

export const getProvider = (): BrowserProvider | null => {
    if (typeof window !== 'undefined' && window.ethereum) {
        return new ethers.BrowserProvider(window.ethereum);
    }
    return null;
};

export const getSigner = async (): Promise<Signer | null> => {
    const provider = getProvider();
    if (provider) {
        return await provider.getSigner();
    }
    return null;
}

export const connectWallet = async (): Promise<{ address: string; chainId: number } | null> => {
    const provider = getProvider();
    if (provider) {
        try {
            const accounts = await provider.send("eth_requestAccounts", []);
            const network = await provider.getNetwork();
            return { address: accounts[0], chainId: Number(network.chainId) };
        } catch (error) {
            console.error("Failed to connect wallet", error);
            return null;
        }
    }
    alert("Please install MetaMask!");
    return null;
};

export const switchNetwork = async (chainId: number): Promise<void> => {
    const provider = getProvider();
    if (provider) {
        try {
            await provider.send("wallet_switchEthereumChain", [{ chainId: `0x${chainId.toString(16)}` }]);
        } catch (error: any) {
            // This error code indicates that the chain has not been added to MetaMask.
            if (error.code === 4902) {
                // Add logic here to add the network if needed
                console.error("This network is not added to your MetaMask.");
            } else {
                console.error("Failed to switch network", error);
            }
        }
    }
};

// Add functions for contract interactions here
// e.g., mintNFT, transferNFT, getOwnedNFTs
