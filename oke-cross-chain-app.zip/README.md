
# OKE Cross-Chain RWA Platform

The OKE app is a proof-of-concept platform for the temporary storage and cross-chain transfer of Real-World Assets (RWAs), represented as NFTs. It leverages Chainlink's Cross-Chain Interoperability Protocol (CCIP) to move assets between the Polygon Mumbai and Ethereum Sepolia testnets.

---

## English

### Overview

This project demonstrates a complete dApp workflow:
1.  **Connect Wallet**: Users connect their Web3 wallet (e.g., MetaMask).
2.  **Create & Mint**: Users can create a new "OKE" item by providing an image and voice data, which is then minted as an ERC-721 NFT on the source chain (Polygon Mumbai).
3.  **View Collection**: Users can see all their OKE NFTs on the currently connected chain.
4.  **Cross-Chain Transfer**: From the item's detail view, users can initiate a transfer to another blockchain (Ethereum Sepolia). The NFT on the source chain is burned, and a new one is minted on the destination chain, orchestrated by CCIP.

### Technology Stack

*   **Frontend**: React, Ethers.js, Framer Motion, Tailwind CSS
*   **Blockchain**: Solidity
*   **Development Environment**: Hardhat
*   **Cross-Chain**: Chainlink CCIP
*   **Testnets**: Polygon Mumbai, Ethereum Sepolia

### Local Setup & Deployment

#### Prerequisites
*   Node.js (v18 or later)
*   Yarn or npm
*   MetaMask browser extension

#### Installation
1.  Clone the repository.
2.  Create a `.env.local` file by copying `.env.local.example`.
    ```bash
    cp .env.local.example .env.local
    ```
3.  Fill in the `.env.local` file with your own:
    *   Testnet RPC URLs (from Alchemy or Infura)
    *   A wallet private key for deployment (from MetaMask - **use a dedicated developer wallet, not your main one**)
    *   Etherscan and Polygonscan API keys (for contract verification)
4.  Install dependencies:
    ```bash
    npm install
    ```

#### Running the App
The frontend app is designed to be run via a local web server. You can use an extension like "Live Server" in VS Code on the `index.html` file.

#### Smart Contract Deployment
1.  **Fund your wallet**: Get some testnet MATIC for Mumbai and Sepolia ETH for Sepolia from a public faucet.
2.  **Deploy Contracts**: Run the deployment script. This will compile, deploy, and configure all smart contracts on both networks.
    ```bash
    npx hardhat run scripts/deploy.ts
    ```
3.  **Update Frontend**: After deployment, copy the contract addresses printed in the console to the `utils/constants.ts` file in the frontend source.

---

## 日本語 (Japanese)

### 概要

OKEアプリは、現実世界の資産（RWA）を表現したNFTを一時的に保管し、クロスチェーンで転送するための概念実証プラットフォームです。ChainlinkのCross-Chain Interoperability Protocol (CCIP)を活用し、Polygon MumbaiとEthereum Sepoliaテストネット間で資産を移動させます。

### 技術スタック

*   **フロントエンド**: React, Ethers.js, Framer Motion, Tailwind CSS
*   **ブロックチェーン**: Solidity
*   **開発環境**: Hardhat
*   **クロスチェーン**: Chainlink CCIP
*   **テストネット**: Polygon Mumbai, Ethereum Sepolia

### ローカルでのセットアップとデプロイ

#### 前提条件
*   Node.js (v18以降)
*   Yarn または npm
*   MetaMaskブラウザ拡張機能

#### インストール
1.  リポジトリをクローンします。
2.  `.env.local.example`をコピーして`.env.local`ファイルを作成します。
    ```bash
    cp .env.local.example .env.local
    ```
3.  `.env.local`ファイルに以下の情報を入力します:
    *   テストネットのRPC URL（AlchemyやInfuraから取得）
    *   デプロイ用のウォレットのプライベートキー（**メインではない開発用のウォレットを使用してください**）
    *   EtherscanとPolygonscanのAPIキー（コントラクトの確認用）
4.  依存関係をインストールします:
    ```bash
    npm install
    ```

#### アプリの実行
フロントエンドアプリはローカルのウェブサーバーで実行するように設計されています。VS Codeの「Live Server」のような拡張機能を`index.html`ファイルに対して使用できます。

#### スマートコントラクトのデプロイ
1.  **ウォレットに資金を入金**: 公開フォーセットから、Mumbai用のテストネットMATICとSepolia用のSepolia ETHを入手します。
2.  **コントラクトのデプロイ**: デプロイスクリプトを実行します。これにより、全てのスマートコントラクトが両方のネットワークにコンパイル、デプロイ、設定されます。
    ```bash
    npx hardhat run scripts/deploy.ts
    ```
3.  **フロントエンドの更新**: デプロイ後、コンソールに出力されたコントラクトアドレスを、フロントエンドソース内の`utils/constants.ts`ファイルにコピーしてください。

