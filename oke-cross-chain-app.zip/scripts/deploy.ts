
import { ethers, network } from "hardhat";
import hre from "hardhat";

// Helper function to verify contracts on Etherscan
async function verify(contractAddress: string, args: any[]) {
  console.log("Verifying contract...");
  try {
    await hre.run("verify:verify", {
      address: contractAddress,
      constructorArguments: args,
    });
  } catch (e: any) {
    if (e.message.toLowerCase().includes("already verified")) {
      console.log("Already verified!");
    } else {
      console.log(e);
    }
  }
}

// Chainlink CCIP contract addresses (replace with actual mainnet/testnet addresses)
const ccipRouters = {
    sepolia: "0x0BF3dE8c5D3e8A2B34D2BE49fe97aEA397a60888",
    mumbai: "0x1035CabC275068e0F4b745A29CEDf38E134A29bF"
};

const linkTokens = {
    sepolia: "0x779877A7B0D9E8603169DdbD7836e478b4624789",
    mumbai: "0x326C977E6efc84E512bB9C30f76E30c160eD06FB"
};

async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying contracts with the account:", deployer.address);
    console.log("Account balance:", (await deployer.provider.getBalance(deployer.address)).toString());

    // --- DEPLOY ON MUMBAI (Source) ---
    console.log("\n--- Deploying on Mumbai ---");
    await network.provider.send("hardhat_setNetwork", [{ chainId: 80001 }]);

    // 1. Deploy OkeNFT on Mumbai
    const okeNftMumbaiFactory = await ethers.getContractFactory("OkeNFT");
    const okeNftMumbai = await okeNftMumbaiFactory.deploy(deployer.address);
    await okeNftMumbai.waitForDeployment();
    const okeNftMumbaiAddress = await okeNftMumbai.getAddress();
    console.log(`OkeNFT (Mumbai) deployed to: ${okeNftMumbaiAddress}`);
    
    // 2. Deploy CCIPSource on Mumbai
    const ccipSourceFactory = await ethers.getContractFactory("CCIPSource");
    const ccipSource = await ccipSourceFactory.deploy(ccipRouters.mumbai, linkTokens.mumbai, okeNftMumbaiAddress);
    await ccipSource.waitForDeployment();
    const ccipSourceAddress = await ccipSource.getAddress();
    console.log(`CCIPSource (Mumbai) deployed to: ${ccipSourceAddress}`);

    // 3. Grant minting/burning roles to CCIPSource contract
    await okeNftMumbai.transferOwnership(ccipSourceAddress);
    console.log(`OkeNFT (Mumbai) ownership transferred to CCIPSource`);


    // --- DEPLOY ON SEPOLIA (Destination) ---
    console.log("\n--- Deploying on Sepolia ---");
    await network.provider.send("hardhat_setNetwork", [{ chainId: 11155111 }]);
    
    // 1. Deploy OkeNFT on Sepolia
    const okeNftSepoliaFactory = await ethers.getContractFactory("OkeNFT");
    const okeNftSepolia = await okeNftSepoliaFactory.deploy(deployer.address);
    await okeNftSepolia.waitForDeployment();
    const okeNftSepoliaAddress = await okeNftSepolia.getAddress();
    console.log(`OkeNFT (Sepolia) deployed to: ${okeNftSepoliaAddress}`);

    // 2. Deploy CCIPDestination on Sepolia
    const ccipDestinationFactory = await ethers.getContractFactory("CCIPDestination");
    const ccipDestination = await ccipDestinationFactory.deploy(ccipRouters.sepolia, okeNftSepoliaAddress);
    await ccipDestination.waitForDeployment();
    const ccipDestinationAddress = await ccipDestination.getAddress();
    console.log(`CCIPDestination (Sepolia) deployed to: ${ccipDestinationAddress}`);
    
    // 3. Grant minting role to CCIPDestination contract
    await okeNftSepolia.transferOwnership(ccipDestinationAddress);
    console.log(`OkeNFT (Sepolia) ownership transferred to CCIPDestination`);

    console.log("\n--- Deployment Summary ---");
    console.log(`MUMBAI_OKE_NFT_ADDRESS=${okeNftMumbaiAddress}`);
    console.log(`MUMBAI_CCIP_SOURCE_ADDRESS=${ccipSourceAddress}`);
    console.log(`SEPOLIA_OKE_NFT_ADDRESS=${okeNftSepoliaAddress}`);
    console.log(`SEPOLIA_CCIP_DESTINATION_ADDRESS=${ccipDestinationAddress}`);

    // Optional: Verification
    if (process.env.ETHERSCAN_API_KEY && process.env.POLYGONSCAN_API_KEY) {
        console.log("\nVerifying contracts on explorers...");
        // You would run these verifications manually or add logic to switch network context
        // await verify(okeNftMumbaiAddress, [deployer.address]);
        // await verify(ccipSourceAddress, [ccipRouters.mumbai, linkTokens.mumbai, okeNftMumbaiAddress]);
        // await verify(okeNftSepoliaAddress, [deployer.address]);
        // await verify(ccipDestinationAddress, [ccipRouters.sepolia, okeNftSepoliaAddress]);
    }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
