
import React, { useState, useEffect } from 'react';
import { WalletConnector } from './components/WalletConnector';
import { Collection } from './components/Collection';
import { OkeCreator } from './components/OkeCreator';
import { ItemModal } from './components/ItemModal';
import { connectWallet, getProvider, switchNetwork } from './utils/web3';
import { MUMBAI_CHAIN_ID } from './utils/constants';
import type { Item, Web3State } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<'wallet' | 'collection' | 'creator'>('wallet');
  const [web3State, setWeb3State] = useState<Web3State>({
    address: null,
    chainId: null,
    provider: null,
    signer: null,
  });
  
  // This state will be populated by blockchain data
  const [items, setItems] = useState<Item[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Item | null>(null);

  useEffect(() => {
    const initWeb3 = async () => {
        const provider = getProvider();
        if (provider) {
            const accounts = await provider.listAccounts();
            if (accounts.length > 0) {
                const network = await provider.getNetwork();
                setWeb3State({
                    address: accounts[0].address,
                    chainId: Number(network.chainId),
                    provider: provider,
                    signer: await provider.getSigner(),
                });
                setView('collection');
            }
        }
    };
    initWeb3();

    if (window.ethereum) {
        window.ethereum.on('accountsChanged', (accounts: string[]) => {
            if (accounts.length > 0) {
                // handle account change
                window.location.reload();
            } else {
                // handle disconnect
                setWeb3State({ address: null, chainId: null, provider: null, signer: null });
                setView('wallet');
            }
        });
        window.ethereum.on('chainChanged', () => {
            window.location.reload();
        });
    }
  }, []);

  const handleConnectWallet = async () => {
    const connection = await connectWallet();
    if (connection) {
        const provider = getProvider();
        setWeb3State({
            address: connection.address,
            chainId: connection.chainId,
            provider,
            signer: provider ? await provider.getSigner() : null,
        });

        if (connection.chainId !== MUMBAI_CHAIN_ID) {
            await switchNetwork(MUMBAI_CHAIN_ID);
        }
        
        setView('collection');
    }
  };

  const handleCreateNew = () => {
    setView('creator');
  };

  const handleGenerateItem = async (imageDataUrl: string, transcript: string) => {
    setIsGenerating(true);
    setView('collection'); 
    
    // In a real app, this would involve:
    // 1. Uploading metadata (image, transcript) to IPFS to get a tokenURI.
    // 2. Calling the mint function on the OkeNFT contract with the tokenURI.
    // 3. Listening for the Mint event and updating the `items` state.
    
    console.log("Simulating minting process...");
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    const newItem: Item = {
      id: Date.now().toString(), // Should be the real tokenId
      image: imageDataUrl,
      transcript: transcript,
      name: 'OKE-' + Math.floor(Math.random() * 1000), 
      description: 'Newly Minted OKE',
      tokenId: Math.floor(Math.random() * 1000), // Placeholder tokenId
    };
    
    setItems(prevItems => [newItem, ...prevItems]);
    setIsGenerating(false);
  };

  const handleItemClick = (item: Item) => {
    setSelectedItem(item);
  };

  const handleCloseModal = () => {
    setSelectedItem(null);
  };

  const renderView = () => {
    if (!web3State.address) {
        return <WalletConnector onConnect={handleConnectWallet} />;
    }

    switch(view) {
      case 'collection':
        return <Collection items={items} isGenerating={isGenerating} onItemClick={handleItemClick} onCreateNew={handleCreateNew} />;
      case 'creator':
        return <OkeCreator onGenerate={handleGenerateItem} onBack={() => setView('collection')} />;
      default:
        return <WalletConnector onConnect={handleConnectWallet} />;
    }
  }

  return (
    <div className="flex flex-col min-h-screen w-full items-center justify-center p-4 bg-black font-sans">
      <div className="w-full max-w-md mx-auto">
        {renderView()}
        {selectedItem && <ItemModal item={selectedItem} web3State={web3State} onClose={handleCloseModal} />}
      </div>
    </div>
  );
};

export default App;
