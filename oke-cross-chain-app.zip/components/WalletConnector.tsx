import React from 'react';

interface WalletConnectorProps {
    onConnect: () => void;
}

export const WalletConnector: React.FC<WalletConnectorProps> = ({ onConnect }) => {
    return (
        <div className="flex flex-col items-center justify-center h-screen text-center animate-fade-in">
            <div className="space-y-6">
                <h1 className="text-5xl font-bold">IDQ</h1>
                <h2 className="text-5xl font-bold">Soulwallet</h2>
            </div>
            <div className="mt-12">
                <button 
                    onClick={onConnect}
                    className="bg-blue-600 text-white font-bold py-3 px-12 rounded-lg text-lg hover:bg-blue-700 transition-transform transform hover:scale-105"
                >
                    ウォレット接続
                </button>
            </div>
             <p className="text-gray-400 mt-16">シーン1 起動とウォレット接続</p>
        </div>
    );
};
