
import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, Mic } from 'lucide-react';
import { Loader } from './Loader';

declare const window: any;

// SpeechRecognition setup
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition: any | null = null;
if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'ja-JP'; // Set to Japanese
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
}

interface OkeCreatorProps {
    onGenerate: (imageDataUrl: string, transcript: string) => void;
    onBack: () => void;
}

export const OkeCreator: React.FC<OkeCreatorProps> = ({ onGenerate, onBack }) => {
    const [selectedImage, setSelectedImage] = useState<string | null>(null);
    const [transcript, setTranscript] = useState('');
    const [isListening, setIsListening] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleSelectImageClick = () => {
        fileInputRef.current?.click();
    };

    const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && file.type.startsWith("image")) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = reader.result as string;
                setSelectedImage(base64String);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleVoiceInputClick = () => {
        if (!recognition) {
            alert("Speech recognition is not supported in this browser.");
            return;
        }
        if (isListening) {
            recognition.stop();
            setIsListening(false);
        } else {
            setTranscript('');
            recognition.start();
            setIsListening(true);
        }
    };

    const handleGenerate = () => {
        if (selectedImage) {
            setIsGenerating(true);
            onGenerate(selectedImage, transcript);
        }
    };

    useEffect(() => {
        if (!recognition) return;

        recognition.onresult = (event: any) => {
            const currentTranscript = event.results[0][0].transcript;
            setTranscript(currentTranscript);
        };
        recognition.onerror = (event: any) => {
            console.error('Speech recognition error', event.error);
            setTranscript('音声認識に失敗しました。');
            setIsListening(false);
        };
        recognition.onend = () => {
            setIsListening(false);
        };

        return () => {
            if (recognition) {
                recognition.onresult = null;
                recognition.onerror = null;
                recognition.onend = null;
            }
        };
    }, []);

    return (
        <div className="bg-black p-4 w-full h-full flex flex-col items-center justify-between animate-fade-in">
            <button onClick={onBack} className="text-gray-400 self-start hover:text-white">← Back to Collection</button>
            <div className="flex flex-col items-center space-y-6 w-full">
                <h1 className="text-5xl font-bold">OKE</h1>
                
                {selectedImage && (
                    <img src={selectedImage} alt="Selected" className="w-32 h-32 rounded-lg object-cover" />
                )}

                <button onClick={handleSelectImageClick} className="w-full max-w-xs bg-gray-800 text-white py-3 px-4 rounded-lg text-lg hover:bg-gray-700 transition-colors duration-200 flex items-center justify-center space-x-2">
                    <UploadCloud size={24} />
                    <span>Select Image</span>
                </button>
                <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageChange} className="hidden" />

                <button onClick={handleVoiceInputClick} disabled={isListening} className="w-full max-w-xs bg-gray-800 text-white py-3 px-4 rounded-lg text-lg hover:bg-gray-700 transition-colors duration-200 flex items-center justify-center space-x-2 disabled:bg-gray-600">
                    <Mic size={24} />
                    <span>{isListening ? '認識中...' : '音声入力'}</span>
                </button>
                
                <p className="text-gray-400 h-6">{transcript}</p>

                <button onClick={handleGenerate} disabled={!selectedImage || isGenerating} className="w-full max-w-xs bg-white text-black py-3 px-4 rounded-lg text-lg font-semibold hover:bg-gray-200 transition-colors duration-200 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center">
                    {isGenerating ? <Loader /> : 'Create OKE Item'}
                </button>
            </div>
            <div className="h-10"></div>
        </div>
    );
};
