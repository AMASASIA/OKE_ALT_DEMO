
import React, { useState } from 'react';
import { Heart, Send, CheckCircle, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { Item, Web3State } from '../types';

interface ItemModalProps {
    item: Item;
    web3State: Web3State;
    onClose: () => void;
}

type TransferStatus = 'idle' | 'confirming' | 'sending' | 'success' | 'error';

export const ItemModal: React.FC<ItemModalProps> = ({ item, web3State, onClose }) => {
    const [status, setStatus] = useState<TransferStatus>('idle');
    const [txHash, setTxHash] = useState('');

    const handleTransfer = async () => {
        // In a real app, this would call the CCIPSource contract
        // const contract = new ethers.Contract(MUMBAI_CCIP_SOURCE_ADDRESS, abi, web3State.signer);
        // const tx = await contract.transferNft(...)
        setStatus('confirming');
        await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate wallet confirmation
        
        setStatus('sending');
        setTxHash('0x' + [...Array(64)].map(() => Math.floor(Math.random() * 16).toString(16)).join(''));
        await new Promise(resolve => setTimeout(resolve, 5000)); // Simulate transaction time
        
        // Randomly succeed or fail for demo purposes
        if (Math.random() > 0.2) {
            setStatus('success');
        } else {
            setStatus('error');
        }
    };

    const statusInfo = {
        confirming: { icon: <Send className="animate-pulse"/>, text: "Confirm in wallet..." },
        sending: { icon: <Send className="animate-spin"/>, text: "Sending to Sepolia..." },
        success: { icon: <CheckCircle className="text-green-400"/>, text: "Transfer Complete!" },
        error: { icon: <XCircle className="text-red-400"/>, text: "Transfer Failed" }
    }

    return (
        <div 
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 animate-fade-in"
            onClick={onClose}
        >
            <motion.div 
                layout
                className="bg-gray-900 rounded-2xl p-6 w-full max-w-sm m-4 flex flex-col items-center space-y-4 shadow-2xl ring-1 ring-gray-700"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="bg-gray-800 w-48 h-48 rounded-lg flex items-center justify-center">
                    <img src={item.image} alt={item.name} className="w-40 h-40 object-cover rounded-md" />
                </div>
                
                <h2 className="text-3xl font-bold">{item.name}</h2>
                <p className="text-gray-400">{item.description}</p>
                <p className="text-xs text-gray-500">Token ID: {item.tokenId}</p>
                
                <AnimatePresence mode="wait">
                    {status === 'idle' ? (
                        <motion.div key="actions" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full flex justify-center space-x-4 pt-2">
                             <button className="p-3 bg-gray-800 rounded-full hover:bg-gray-700 transition-colors">
                                <Heart size={24} className="text-white" />
                            </button>
                            <button 
                                onClick={handleTransfer}
                                className="flex-grow bg-blue-600 text-white font-bold py-3 rounded-lg text-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
                            >
                                <Send size={20} />
                                <span>Transfer to another chain</span>
                            </button>
                        </motion.div>
                    ) : (
                        <motion.div 
                            key="status"
                            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                            className="w-full text-center py-4 space-y-2"
                        >
                            <div className="flex justify-center items-center space-x-3 text-lg">
                                {statusInfo[status].icon}
                                <span>{statusInfo[status].text}</span>
                            </div>
                            {txHash && (
                                <p className="text-xs text-gray-400 truncate">Tx: {txHash}</p>
                            )}
                            {(status === 'success' || status === 'error') && (
                                <button onClick={onClose} className="text-blue-400 text-sm pt-2">Close</button>
                            )}
                        </motion.div>
                    )}
                </AnimatePresence>
            </motion.div>
        </div>
    );
};
