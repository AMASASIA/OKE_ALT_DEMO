import React from 'react';
import type { Item } from '../types';

interface CollectionProps {
    items: Item[];
    isGenerating: boolean;
    onItemClick: (item: Item) => void;
    onCreateNew: () => void;
}

const ItemCard: React.FC<{ item: Item, onClick: () => void }> = ({ item, onClick }) => (
    <div 
        className="aspect-square bg-gray-800 rounded-lg flex flex-col items-center justify-center text-center p-2 cursor-pointer hover:bg-gray-700 transition-colors"
        onClick={onClick}
    >
        <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded-md mb-2" />
        <span className="text-lg font-bold">{item.name}</span>
    </div>
);

const PlaceholderCard: React.FC = () => (
    <div className="aspect-square bg-gray-800/50 rounded-lg border-2 border-dashed border-gray-700" />
);


export const Collection: React.FC<CollectionProps> = ({ items, isGenerating, onItemClick, onCreateNew }) => {
    const gridItems = [...items, ...Array(Math.max(0, 8 - items.length)).fill(null)];

    return (
        <div className="p-4 bg-black w-full text-center animate-fade-in">
            <h2 className="text-2xl font-bold mb-6">生成されたアイテム</h2>

            <div className="grid grid-cols-3 gap-3">
                {gridItems.map((item, index) => 
                    item ? (
                        <ItemCard key={item.id} item={item} onClick={() => onItemClick(item)} />
                    ) : (
                        <PlaceholderCard key={index} />
                    )
                )}
            </div>

            <div className="mt-8">
                {isGenerating ? (
                    <div className="bg-gray-800 text-white font-bold py-3 px-12 rounded-lg text-lg inline-block">
                        生成読込中…
                    </div>
                ) : (
                    <button 
                        onClick={onCreateNew}
                        className="bg-blue-600 text-white font-bold py-3 px-12 rounded-lg text-lg hover:bg-blue-700"
                    >
                        Create New Item
                    </button>
                )}
            </div>
            <p className="text-gray-400 mt-8">2 コレクション画面</p>
        </div>
    );
};
