
import { BrowserProvider, Signer } from "ethers";

export interface Item {
  id: string;
  image: string;
  name: string;
  description: string;
  transcript: string;
  tokenId: number;
}

export interface Web3State {
    address: string | null;
    chainId: number | null;
    provider: BrowserProvider | null;
    signer: Signer | null;
}
